/* LandonBunker, 
CS 1450,
section T and TR, 
Assignment 2, 
due: 9/30/21, 
model a railroad by creating a sorting yard and reading the number of tracks from a file.
*/

//import libraries
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BunkerLandonAssignment4 {

	public static void main(String[] args) throws IOException {
		
		// open the file and put it into a variable as well as create a scanner variable
		File inputFileName = new File("Trains.txt");
		Scanner inputFile = new Scanner (inputFileName);
		
		//creating the railroad
		int sizeOfTrainArray  = inputFile.nextInt();
		Railroad railroad = new Railroad(sizeOfTrainArray);
		
		
		// read next into variables in order to create objects
		int trackNumber = 0;
		int engineNumber = 0; 
		String company = ""; 
		int numberRailCars = 0;
		String type = ""; 
		String destination = "";
					
		//for loop to create the train object and put it into the railroad object
		while (inputFile.hasNext()) {
			
			trackNumber = inputFile.nextInt();
			engineNumber = inputFile.nextInt();
			company = inputFile.next();
			numberRailCars = inputFile.nextInt();
			type = inputFile.next();
			destination = inputFile.nextLine();
			
			//create the train object and place it into the sorting yard using the add train to sorting yeard method
			Train tempTrain = new Train(engineNumber, company, numberRailCars, type, destination);
			railroad.addTrainToSortingYard(trackNumber, tempTrain);
		}
		
		// call display sorting yard and print train report
		railroad.displaySortingYard();
		printTrainReport(railroad);
		
		inputFile.close();
	}


	//print train report method by using an arraylist 
	public static void printTrainReport(Railroad railroad) {
		
		ArrayList<Train> sortedRailroad= new ArrayList<Train>();
		
		for (int i = 0; i < railroad.getNumberTracks(); i++) {
			if (railroad.getTrainInSortingYard(i) != null ) {
				sortedRailroad.add(railroad.getTrainInSortingYard(i)); 
			}	
		}
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("\t\tTrain Report");
		System.out.println("\t\t(ordered by number of rail cars)");
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("Engine\tCompany\t\tRail Cars\tType\t\tDestination");
		System.out.println("-------------------------------------------------------------------------------------------");
		
		//use collecitons.sort which will the comparable function
		Collections.sort(sortedRailroad);
		
		//print the railroad using a for loop
		for (int i =0; i< sortedRailroad.size(); i++) {
			System.out.println(sortedRailroad.get(i));
		}
	}
	

}	
// create the railroad class and use a nested object inside to create the sorting yard
class Railroad {
	private Train sortingYard[];
	int numberTracks;
	
	public Railroad(int numberTracks) {
		this.numberTracks = numberTracks;
		sortingYard = new Train[numberTracks];
	}
	
	public int getNumberTracks() {
		return numberTracks;
	}
	
	public void addTrainToSortingYard (int trackNumber, Train train ) {
		sortingYard[trackNumber] = train;
	}
	
	public Train getTrainInSortingYard(int trackNumber) {
		if (sortingYard[trackNumber] != null) {
			return sortingYard[trackNumber];
		}
		
		else {
			return null;
		}
	}
	
	//display sorting method
	public void displaySortingYard() {
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("Track\tEngine\tCompany\t\tRail Cars\tType\t\tDestination");
		System.out.println("-------------------------------------------------------------------------------------------");
		
		
		for (int i = 0; i < sortingYard.length; i++) {
			if (sortingYard[i] ==  null) {
				System.out.println( i + "\t ----\t----\t\t----\t\t----\t\t----\n");
			}
			
			else {
				System.out.println(i + "\t " + sortingYard[i] + "\n");
			}
		}
	}
}

//create train class as well as implement the comparable object
class Train implements Comparable<Train>{
	int engineNumber;
	String company;
	int numberRailCars;
	String type;
	String destinationCity;
	
	public Train(int engineNumber, String company, int numberRailCars,  String type, String destinationCity) {
		this.engineNumber = engineNumber;
		this.company = company;
		this.numberRailCars = numberRailCars;
		this.type = type;
		this.destinationCity = destinationCity;
	}
	
	public int getEngineNumber() {
		return engineNumber;
	}
	
	public String getCompany() {
		return company;
	}
	
	public int getNumberRailCars() {
		return numberRailCars;
	}
	
	public String getType() {
		return type;
	}
	
	public String getDestinationCity() {
		return destinationCity;
	}
	
	@Override
	public String toString() {
		return String.format("%d\t%s\t\t%d\t\t%-15s\t%s", engineNumber,  company,  numberRailCars,  type,  destinationCity);
	}
	
	@Override
	public int compareTo(Train otherTrain) {
		if (otherTrain.getNumberRailCars() < this.getNumberRailCars() ) {
			return -1;
		}
		
		else if (otherTrain.getNumberRailCars() == this.getNumberRailCars()) {
			return 0;
		}
		
		else  {
			return 1;
		}
	}
	
	
}

	

