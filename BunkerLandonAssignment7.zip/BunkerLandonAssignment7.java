/* LandonBunker, 
CS 1450,
section T and TR, 
Assignment 7, 
due: 10/29/21, 
model a railroad by using queues and priority queues to create a recving track and a departure track.
*/

//import libraries
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;

public class BunkerLandonAssignment4 {

	public static void main(String[] args) throws IOException {
		
		// open the file and put it into a variable as well as create a scanner variable
		File inputFileName = new File("Trains7.txt");
		Scanner inputFile = new Scanner (inputFileName);
		
		
		//creating the railroad
		int sizeOfTrainArray  = inputFile.nextInt();
		Railroad railroad = new Railroad(sizeOfTrainArray);
		
		
		// read next into variables in order to create objects
		int trackNumber = 0;
		int engineNumber = 0; 
		String company = ""; 
		int numberRailCars = 0;
		String type = ""; 
		String destination = "";
					
		//for loop to create the train object and put it into the railroad object
		while (inputFile.hasNext()) {
			
			trackNumber = inputFile.nextInt();
			engineNumber = inputFile.nextInt();
			company = inputFile.next();
			numberRailCars = inputFile.nextInt();
			type = inputFile.next();
			destination = inputFile.nextLine();
			
			company = company.trim();
			type = type.trim();
			destination =destination.trim();
			
			//create the train object and place it into the sorting yard using the add train to sorting yard method
			Train tempTrain = new Train(engineNumber, company, numberRailCars, type, destination);
			railroad.addTrainToSortingYard(trackNumber, tempTrain);
		}
		
		// call display sorting yard and print train report
		System.out.println("Loading trains onto tracks in sorting yard...\n\n");
		railroad.displaySortingYard();
		
		
		// close first file
		inputFile.close();
		
		//open the railcar file
		inputFileName = new File("RailCars7.txt");
		inputFile = new Scanner (inputFileName);
		
		//initialize variables to create the railcars
		int railCarNumber = 0;
		String railCarType = "";
		String railCarDestination = "";
		
		//while loop to read in values into varaibles to creat railcars and add them to receiving track
		while(inputFile.hasNext()) {
			railCarNumber = inputFile.nextInt();
			railCarType = inputFile.next();
			railCarDestination = inputFile.next();
			
			RailCar tempRailCar = new RailCar(railCarNumber, railCarType, railCarDestination);
			railroad.addRailCarToReceivingTrack(tempRailCar);
		}
		
		//call display receiving track
		railroad.displayReceivingTrack();

		//create controller for railroad
		RailroadController controller = new RailroadController();
		
		//call move railcard to the matching trains
		controller.moveRailCarsToTrains(railroad);
		
		//display new sorting yard
		System.out.println("\n\nShow sorting yard with trains and rail cars...");
		railroad.displaySortingYard();
		
		System.out.println("Controller: Moving trains from sorting yard to departure track");
		System.out.println("-------------------------------------------------------------------------------------------");
		
		//move trains to departure track
		controller.moveTrainsToDepartureTrack(railroad);
		
		System.out.println("\n\nController: Moving trains from departure track to main line - longer trains go first");
		System.out.println("-------------------------------------------------------------------------------------------");
		
		//move the trains to deaprture track
		controller.clearedForDeparture(railroad);
		
		System.out.println("\n\nShow sorting yard with no trains...");
		
		//display empty sorting yard
		railroad.displaySortingYard();

		System.out.println("\n\nEnd railroad yard simulation...");
		
		//close the second file
		inputFile.close();

}	
}
// create the railroad class and use a nested object inside to create the sorting yard
class Railroad {
	private Queue<RailCar> receivingTrack;
	private PriorityQueue<Train> departureTrack;
	private Train sortingYard[];
	int numberTracks;
	
	public Railroad(int numberTracks) {
		this.numberTracks = numberTracks;
		sortingYard = new Train[numberTracks];
		receivingTrack = new LinkedList<RailCar>();
		departureTrack= new PriorityQueue<Train>();
	}
	
	public int getNumberTracks() {
		return numberTracks;
	}
	
	public void addTrainToSortingYard (int trackNumber, Train train ) {
		sortingYard[trackNumber] = train;
	}
	
	public Train getTrainInSortingYard(int trackNumber) {
		if (sortingYard[trackNumber] != null) {
			return sortingYard[trackNumber];
		}
		
		else {
			return null;
		}
	}
	
	public void displaySortingYard() {
		
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("Track\tEngine\tCompany\t\tRail Cars\tType\t\tDestination");
		System.out.println("-------------------------------------------------------------------------------------------");
		
		
		for (int i = 0; i < sortingYard.length; i++) {
			if (sortingYard[i] ==  null) {
				System.out.println( i + "\t ----\t----\t\t----\t\t----\t\t----\n");
			}
			
			else {
				System.out.println(i + "\t " + sortingYard[i] + "\n");
			}
		}
	}
	
	public boolean isReceivingTrackEmpty( ) {
		if (receivingTrack.isEmpty()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void addRailCarToReceivingTrack(RailCar railcar) {
		receivingTrack.add(railcar);
	}
	
	public RailCar removeRailCarFromReceivingTrack() {
		RailCar tempCar = receivingTrack.remove();
		return tempCar;
	}
	
	public boolean isDepartureTrackEmpty() {
		if(departureTrack.isEmpty()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void addTrainToDepartureTrack(Train train) {
		departureTrack.add(train);
	}
	
	public Train removeTrainFromDepartureTrack() {
		Train tempTrain = departureTrack.remove();
		return tempTrain;
	}
	
	//find train method that will match the incoming railcar to a matching train
	public int findTrain(RailCar railcar) {
		int returnIndex = 0;
		String railCarDestination = railcar.getDestination();
		String railCarType = railcar.getType();
		for (int i =0; i < sortingYard.length; i++) {
			if (sortingYard[i] == null) {
				
			}
			
			else if (railCarDestination.equals(sortingYard[i].getDestinationCity()) && railCarType.equals(sortingYard[i].getType())) {
				returnIndex = i;
			}
		}
		
		return returnIndex;
	}
	
	public void addRailCarToTrainInSortingYard(RailCar railcar, int trackNumber) {
		sortingYard[trackNumber].addRailCar(railcar);
	}
	
	public void removeTrainFromSortingYard(int trackNumber) {
		sortingYard[trackNumber] = null;
	}
	
	public void displayReceivingTrack() {
		System.out.println("\n\nLoading rail cars on receiving track...");
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("Number\tType\t\tDestination");
		System.out.println("-------------------------------------------------------------------------------------------");
		
		Iterator<RailCar> itr = receivingTrack.iterator();
		while (itr.hasNext()) {
			RailCar tempRailCar = itr.next();
			
			System.out.println(tempRailCar.getNumber() + "\t" + tempRailCar.getType() + "\t\t" + tempRailCar.getDestination());
				
		}
		
	}
}

//create train class as well as implement the comparable object
class Train implements Comparable<Train>{
	private int engineNumber;
	private String company;
	private int numberRailCars;
	private String type;
	private String destinationCity;
	private Queue<RailCar> railCars = new LinkedList<RailCar>();
	
	public Train(int engineNumber, String company, int numberRailCars,  String type, String destinationCity) {
		this.engineNumber = engineNumber;
		this.company = company;
		this.numberRailCars = numberRailCars;
		this.type = type;
		this.destinationCity = destinationCity;
	}
	
	public int getEngineNumber() {
		return engineNumber;
	}
	
	public String getCompany() {
		return company;
	}
	
	public int getNumberRailCars() {
		return numberRailCars;
	}
	
	public String getType() {
		return type;
	}
	
	public String getDestinationCity() {
		return destinationCity;
	}
	
	@Override
	public String toString() {
		return String.format("%d\t%s\t\t%d\t\t%-15s\t%s", engineNumber,  company,  numberRailCars,  type,  destinationCity);
	}
	
	@Override
	public int compareTo(Train otherTrain) {
		if (otherTrain.getNumberRailCars() < this.getNumberRailCars() ) {
			return -1;
		}
		
		else if (otherTrain.getNumberRailCars() == this.getNumberRailCars()) {
			return 0;
		}
		
		else  {
			return 1;
		}
	}
	
	public void addRailCar (RailCar railcar) {
		railCars.add(railcar);
		numberRailCars++;
	}
	
}

class RailCar {
	private int number;
	private String type;
	private String destination;
	
	public RailCar(int number, String type, String destination) {
		this.number = number;
		this.type = type;
		this.destination = destination;
	}
	
	public int getNumber() {
		return number;
	}
	
	public String getType() {
		return type;
	}
	
	public String getDestination() {
		return destination;
	}
	
}

class RailroadController {
	//method to move the incoming rail car to a train that matches by also using the find train method
	public void moveRailCarsToTrains (Railroad railroad) {
		System.out.println("Start railroad yard simulation...\n\n");
		System.out.println("Controller: Moving rail cars from receiving track to correct sorting yard track: \n\n");
		int trainIndex = 0;
		while(!railroad.isReceivingTrackEmpty()) {
			RailCar tempRailCar = railroad.removeRailCarFromReceivingTrack();
			trainIndex = railroad.findTrain(tempRailCar);
			railroad.addRailCarToTrainInSortingYard(tempRailCar, trainIndex);
			
			System.out.printf("Moved to sorting track #%d: rail car %d going to %s (%s) \n", trainIndex, tempRailCar.getNumber(), tempRailCar.getDestination(), tempRailCar.getType());
		}
	}
	
	//method to move the trains from sorting yard into the departure yard
	public void moveTrainsToDepartureTrack (Railroad railroad) {
			for(int i =0; i < railroad.numberTracks; i++) {
			
				if (railroad.getTrainInSortingYard(i) == null) {
					
				}
				else {
					Train tempTrain = railroad.getTrainInSortingYard(i);
					railroad.addTrainToDepartureTrack(tempTrain);
					railroad.removeTrainFromSortingYard(i);
					System.out.printf("Moved to departure track: Train %d going to %s (%s)\n", tempTrain.getEngineNumber(), tempTrain.getDestinationCity(), tempTrain.getType());
				}
			}
				
				
		}
	//move the train from the departure yard and print the train that has left
	public void clearedForDeparture (Railroad railroad) {
		while(!railroad.isDepartureTrackEmpty()) {
			Train tempTrain =  railroad.removeTrainFromDepartureTrack();
			System.out.printf("Train %d with %d rail cars is departing to %s (%s)\n" , tempTrain.getEngineNumber(), tempTrain.getNumberRailCars(), tempTrain.getDestinationCity(), tempTrain.getType());		
			}
	}
}
