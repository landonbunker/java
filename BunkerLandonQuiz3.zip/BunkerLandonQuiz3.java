
public class BunkerLandonQuiz3 {

	public static void main(String[] args) {
		int[] numbers = {7,9,1,8,6,4,2};
		double  averageNumber = computeAverage(numbers);
		System.out.printf("Average of array values =  " );
		System.out.printf("%.2f %s", averageNumber, "\n" );
		 
		final int NUM_ATHLETES = 8;
		 
		AthleteQ athlete1 = new AthleteQ("Haley Anderson", "USA", 26);
		AthleteQ athlete2 = new AthleteQ("Leonie Beck", "Germany", 2);
		AthleteQ athlete3 = new AthleteQ("Pieter Timmers", "Belgium", 5);
		AthleteQ athlete4 = new AthleteQ("Alain Bernard", "France", 7);
		AthleteQ athlete5 = new AthleteQ("Caeleb Dressel", "USA", 1);
		AthleteQ athlete6 = new AthleteQ("Katie Ledecky", "USA", 3);
		AthleteQ athlete7 = new AthleteQ("Kyle Chalmers", "Australia", 12);
		AthleteQ athlete8 = new AthleteQ("Luca Urlando", "USA", 6);
		 
		AthleteQ[] athletes = new AthleteQ[NUM_ATHLETES];
		 
		athletes[0] = athlete1;
		athletes[1] = athlete2;
		athletes[2] = athlete3;
		athletes[3] = athlete4;
		athletes[4] = athlete5;
		athletes[5] = athlete6;
		athletes[6] = athlete7;
		athletes[7] = athlete8;
		 
		double averageWorldRanking =  AthleteQ.computeAverage(athletes);
		System.out.println("Average world ranking of the all athletes = " + averageWorldRanking);
		
		int numberOfAthletesFromCountry = AthleteQ.findNumAthletes(athletes, "USA");
		System.out.println("Number of Athletes from USA = " + numberOfAthletesFromCountry);
		
		System.out.println("Name\t\tCountry\t\tWorldRanking");
		System.out.println("------------------------------------------------");
		
		AthleteQ [] AthletesFromCountry = AthleteQ.findAthletes(athletes, numberOfAthletesFromCountry, "USA");
		AthleteQ.displayAthletes(AthletesFromCountry);
		
		
		 
	}

	public static double computeAverage (int[] array) {
		double sum = 0;
		double dividend = array.length;
		for (int i = 0; i < array.length; i++) {
			sum = sum + array[i];
		
		}
		double average = sum/dividend;
		
		return average;
	}
}

class AthleteQ {
	private String name;
	private String country;
	private int worldRanking;
	
	public AthleteQ(String name, String country, int worldRanking){
		this.name = name;
		this.country = country;
		this.worldRanking = worldRanking;
}
	public String getName() {
		return name;
}
	public int getWorldRanking() {
		return worldRanking;
}
	
	public String getcountry() {
		return country;
}
	public static double computeAverage (AthleteQ[] athletes) {
		double sum = 0;
		for (int i =0; i < athletes.length; i++) {
			sum = athletes[i].getWorldRanking() + sum;
			
		}
		double average = sum/athletes.length;
		return average;
	}
	public static int findNumAthletes (AthleteQ[] athletes, String country) {
		int numAthletes = 0;
		for (int i = 0; i < athletes.length; i++) {
			if (athletes[i].getcountry() == country) {
				numAthletes++;
			}
		}
		return numAthletes;
		
	}

	public static AthleteQ[] findAthletes(AthleteQ[] athletes, int numAthletes, String country) {
		AthleteQ[] athletesFromCountry = new AthleteQ[numAthletes];
		int counter = 0;
		for (int i = 0; i < athletes.length; i++){
			
			if (athletes[i].getcountry() == country){
				athletesFromCountry[counter] = athletes[i];
				counter++;
			}	
		}
		return athletesFromCountry;
	}
	public static void displayAthletes(AthleteQ[] athletes) {
		for (int i = 0; i< athletes.length; i++) {
			System.out.println(athletes[i].getName() +"\t" + athletes[i].getcountry() + "\t\t" + athletes[i].getWorldRanking());
		}
	}
}

